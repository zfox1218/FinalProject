package com.example.zoey.petplanner;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class SundayTasksActivity extends AppCompatActivity {
private EditText mEditTaskSun;
private Button mAddSun, mRemoveSun;
    private ListView mListViewSun;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sunday_tasks);
            mEditTaskSun=(EditText)findViewById(R.id.add_task_sun);
            mAddSun=(Button)findViewById(R.id.add_task_button_sun);
            mListViewSun = (ListView) findViewById(R.id.sunday_list);
            mRemoveSun=(Button)findViewById(R.id.remove_task_button_sun);
            final ArrayList<String>SunArray = new ArrayList<String>();
            final ArrayAdapter<String> adapter_sun = new ArrayAdapter(this, R.layout.listview_sunday, SunArray);
            mListViewSun.setAdapter(adapter_sun);
            mAddSun.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final String user_input_mon = mEditTaskSun.getText().toString();
                    adapter_sun.add(user_input_mon);
                    adapter_sun.notifyDataSetChanged();
            mRemoveSun.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            adapter_sun.remove(SunArray.get(SunArray.size()-1));
                            adapter_sun.notifyDataSetChanged();
                        }});;}});}}