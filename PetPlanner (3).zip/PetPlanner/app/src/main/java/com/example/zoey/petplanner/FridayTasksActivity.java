package com.example.zoey.petplanner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class FridayTasksActivity extends AppCompatActivity {
    private EditText mEditTaskFri;
    private Button mAddFri, mRemoveFri;
    private ListView mListViewFri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friday_tasks);
        mEditTaskFri=(EditText)findViewById(R.id.add_task_fri);
        mAddFri=(Button)findViewById(R.id.add_task_button_fri);
        mListViewFri = (ListView) findViewById(R.id.friday_list);
        mRemoveFri=(Button)findViewById(R.id.remove_task_button_fri);
        final ArrayList<String> FriArray = new ArrayList<String>();
        final ArrayAdapter<String> adapter_fri = new ArrayAdapter(this, R.layout.listview_friday, FriArray);
        mListViewFri.setAdapter(adapter_fri);
        mAddFri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String user_input_fri = mEditTaskFri.getText().toString();
                adapter_fri.add(user_input_fri);
                adapter_fri.notifyDataSetChanged();
        mRemoveFri.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        adapter_fri.remove(FriArray.get(FriArray.size()-1));
                        adapter_fri.notifyDataSetChanged();


                    }});;}});}}
