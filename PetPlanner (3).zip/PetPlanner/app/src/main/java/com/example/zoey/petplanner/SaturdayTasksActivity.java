package com.example.zoey.petplanner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class SaturdayTasksActivity extends AppCompatActivity {
    private EditText mEditTaskSat;
    private Button mAddSat, mRemoveSat;
    private ListView mListViewSat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saturday_tasks);
        mEditTaskSat=(EditText)findViewById(R.id.add_task_sat);
        mAddSat=(Button)findViewById(R.id.add_task_button_sat);
        mListViewSat = (ListView) findViewById(R.id.saturday_list);
        mRemoveSat=(Button)findViewById(R.id.remove_task_button_sat);
        final ArrayList<String> SatArray = new ArrayList<String>();
        final ArrayAdapter<String> adapter_sat = new ArrayAdapter(this, R.layout.listview_saturday, SatArray);
        mListViewSat.setAdapter(adapter_sat);
        adapter_sat.add("walk dog");
        adapter_sat.notifyDataSetChanged();
        mAddSat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String user_input_sat = mEditTaskSat.getText().toString();
                adapter_sat.add(user_input_sat);
                adapter_sat.notifyDataSetChanged();
         mRemoveSat.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        adapter_sat.remove(SatArray.get(SatArray.size()-1));
                        adapter_sat.notifyDataSetChanged();


                    }});;}});}}

