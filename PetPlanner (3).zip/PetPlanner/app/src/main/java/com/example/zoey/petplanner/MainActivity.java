package com.example.zoey.petplanner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button mDaysButton,mContactButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mDaysButton=(Button)findViewById(R.id.days_button);
        mContactButton=(Button)findViewById(R.id.contact_button) ;
        mDaysButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, DaysActivity.class);
                startActivity(i);
            }});

    mContactButton.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            Intent i = new Intent(MainActivity.this,ContactActivity.class);
            startActivity(i);
    }});};}