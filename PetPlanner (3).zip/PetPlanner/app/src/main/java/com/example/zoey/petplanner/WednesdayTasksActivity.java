package com.example.zoey.petplanner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class WednesdayTasksActivity extends AppCompatActivity {
    private EditText mEditTaskWed;
    private Button mAddWed, mRemoveWed;
    private ListView mListViewWed;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wednesday_tasks);
        mEditTaskWed=(EditText)findViewById(R.id.add_task_wed);
        mAddWed=(Button)findViewById(R.id.add_task_button_wed);
        mListViewWed = (ListView) findViewById(R.id.wednesday_list);
        mRemoveWed=(Button)findViewById(R.id.remove_task_button_wed);
        final ArrayList<String> WedArray = new ArrayList<String>();
        final ArrayAdapter<String> adapter_wed = new ArrayAdapter(this, R.layout.listview_wednesday, WedArray);
        mListViewWed.setAdapter(adapter_wed);
        mAddWed.setOnClickListener(new View.OnClickListener() {
            @Override
         public void onClick(View v) {
                final String user_input_wed = mEditTaskWed.getText().toString();
                adapter_wed.add(user_input_wed);
                adapter_wed.notifyDataSetChanged();
        mRemoveWed.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        adapter_wed.remove(WedArray.get(WedArray.size()-1));
                        adapter_wed.notifyDataSetChanged();


                    }});;}});}}