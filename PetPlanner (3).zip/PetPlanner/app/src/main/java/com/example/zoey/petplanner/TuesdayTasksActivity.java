package com.example.zoey.petplanner;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class TuesdayTasksActivity extends AppCompatActivity {
    private EditText mEditTaskTues;
    private Button mAddTues, mRemoveTues;
    private ListView mListViewTues;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tuesday_tasks);
        mEditTaskTues=(EditText)findViewById(R.id.add_task_tues);
        mAddTues=(Button)findViewById(R.id.add_task_button_tues);
        mListViewTues = (ListView) findViewById(R.id.tuesday_list);
        mRemoveTues=(Button)findViewById(R.id.remove_task_button_tues);
        final ArrayList<String> TuesArray = new ArrayList<String>();
        final ArrayAdapter<String> adapter_tues = new ArrayAdapter(this, R.layout.listview_tuesday, TuesArray);
        mListViewTues.setAdapter(adapter_tues);
        mAddTues.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String user_input_tues = mEditTaskTues.getText().toString();
                adapter_tues.add(user_input_tues);
                adapter_tues.notifyDataSetChanged();
        mRemoveTues.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        adapter_tues.remove(TuesArray.get(TuesArray.size()-1));
                        adapter_tues.notifyDataSetChanged();


                    }});;}});}}