package com.example.zoey.petplanner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.R.attr.name;

public class ContactActivity extends AppCompatActivity {
private Button mSendButton;
private EditText mName, mEmail, mSubject, mMessage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        mSendButton=(Button)findViewById(R.id.send_button);
        mName=(EditText) findViewById(R.id.name);
        mEmail=(EditText) findViewById(R.id.email);
        mSubject=(EditText)findViewById(R.id.subject);
        mMessage=(EditText)findViewById(R.id.message);
        String EXTRA_name=mName.getText().toString();
        mName.setText(EXTRA_name);
        mSendButton.setOnClickListener(((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent send=new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_EMAIL  , new String[]{ mEmail.getText().toString()});
                send.putExtra(Intent.EXTRA_SUBJECT, mSubject.getText().toString());
                send.putExtra(Intent.EXTRA_TEXT   , mMessage.getText().toString());
                if (send.resolveActivity(getPackageManager()) != null) {
                    startActivity(send);
                    finish();
                }
                else {
                    Toast.makeText(ContactActivity.this, "No email application found",Toast.LENGTH_SHORT).show();
            };
    }
})));}}
