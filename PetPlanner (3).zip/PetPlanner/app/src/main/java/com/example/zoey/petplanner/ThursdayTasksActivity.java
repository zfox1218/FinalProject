package com.example.zoey.petplanner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class ThursdayTasksActivity extends AppCompatActivity {
    private EditText mEditTaskThurs;
    private Button mAddThurs, mRemoveThurs;
    private ListView mListViewThurs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thursday_tasks);
        mEditTaskThurs=(EditText)findViewById(R.id.add_task_thurs);
        mAddThurs=(Button)findViewById(R.id.add_task_button_thurs);
        mListViewThurs = (ListView) findViewById(R.id.thursday_list);
        mRemoveThurs=(Button)findViewById(R.id.remove_task_button_thurs);
        final ArrayList<String> ThursArray = new ArrayList<String>();
        final ArrayAdapter<String> adapter_thurs = new ArrayAdapter(this, R.layout.listview_thursday, ThursArray);
        mListViewThurs.setAdapter(adapter_thurs);
        mAddThurs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String user_input_fri = mEditTaskThurs.getText().toString();
                adapter_thurs.add(user_input_fri);
                adapter_thurs.notifyDataSetChanged();
         mRemoveThurs.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        adapter_thurs.remove(ThursArray.get(ThursArray.size()-1));
                        adapter_thurs.notifyDataSetChanged();


                    }});;}});}}
