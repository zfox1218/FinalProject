package com.example.zoey.petplanner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class DaysActivity extends AppCompatActivity {
private Button mSunday, mMonday, mTuesday, mWednesday, mThursday, mFriday, mSaturday;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_days);
        mSunday=(Button)findViewById(R.id.sunday_button);
        mMonday=(Button)findViewById(R.id.monday_button);
        mTuesday=(Button)findViewById(R.id.tuesday_button);
        mWednesday=(Button)findViewById(R.id.wednesday_button);
        mThursday= (Button)findViewById(R.id.thursday_button);
        mFriday=(Button)findViewById(R.id.friday_button);
        mSaturday=(Button)findViewById(R.id.saturday_button);
        mSunday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sun=new Intent (DaysActivity.this, SundayTasksActivity.class);
                startActivity(sun);
            }});
        mMonday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mon=new Intent (DaysActivity.this,MondayTasksActivity.class);
                startActivity(mon);
            }});
        mTuesday.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent tues=new Intent (DaysActivity.this,TuesdayTasksActivity.class);
                startActivity(tues);
            }}));
        mWednesday.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent wed = new Intent(DaysActivity.this,WednesdayTasksActivity.class);
                startActivity(wed);
            }}));
        mThursday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              Intent thurs = new Intent(DaysActivity.this, ThursdayTasksActivity.class);
               startActivity(thurs);
            }});
        mFriday.setOnClickListener((new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                Intent fri = new Intent(DaysActivity.this, FridayTasksActivity.class);
                  startActivity(fri);
                            }}));
        mSaturday.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                Intent sat=new Intent (DaysActivity.this, SaturdayTasksActivity.class);
                  startActivity(sat);
                                    }});
            }}
