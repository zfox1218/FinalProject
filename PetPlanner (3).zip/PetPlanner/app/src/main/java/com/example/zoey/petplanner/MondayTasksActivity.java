package com.example.zoey.petplanner;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MondayTasksActivity extends AppCompatActivity {
    private EditText mEditTaskMon;
    private Button mAddMon, mRemoveMon;
    private ListView mListViewMon;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monday_tasks);
        mEditTaskMon=(EditText)findViewById(R.id.add_task_mon);
        mAddMon=(Button)findViewById(R.id.add_task_button_mon);
        mListViewMon = (ListView) findViewById(R.id.monday_list);
        mRemoveMon=(Button)findViewById(R.id.remove_task_button_mon);
        final ArrayList<String> MonArray = new ArrayList<String>();
        final ArrayAdapter<String> adapter_mon = new ArrayAdapter(this, R.layout.listview_monday, MonArray);
        mListViewMon.setAdapter(adapter_mon);
        mAddMon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String user_input_mon = mEditTaskMon.getText().toString();
                adapter_mon.add(user_input_mon);
                adapter_mon.notifyDataSetChanged();
        mRemoveMon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            adapter_mon.remove(MonArray.get(MonArray.size()-1));
            adapter_mon.notifyDataSetChanged();
}});;}});}}